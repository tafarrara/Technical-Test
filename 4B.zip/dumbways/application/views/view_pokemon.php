<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>dumbways</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo base_url('asset/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/animate.css') ?>" rel="stylesheet">
        <link href="<?php echo base_url('asset/css/style.css') ?>" rel="stylesheet">
        <link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'>
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" rel="stylesheet" type='text/css'>
        <link href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet">

        <!-- Template js -->
        <script src="<?php echo base_url('asset/js/jquery-2.1.1.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/bootstrap.min.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jquery.appear.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/jqBootstrapValidation.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/modernizr.custom.js') ?>"></script>
        <script src="<?php echo base_url('asset/js/script.js') ?>"></script>

        <!--Tabel -->
        <script src="http://code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
        <script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#tabeldata').DataTable();
            });
        </script>

    </head>

    <body>

        <!-- Start Feature Section -->
        <div class="section-modal" >
            <div class="">
                <div class="close-modal" data-dismiss="modal">
                    <a href="<?php echo base_url() ?>"><img src="asset/images/close.png"></a>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3>DATA POKEMON</h3>
                        </div>
                    </div>
                   <div class="btn-toolbar" style="float: right; margin-top: 3em">
                        <?php if (isset($this->session->userdata['login'])) { ?>
                        <a href="#form-elemen" data-toggle="modal" class="fa fa-plus"><b> Add Elemen</b></a>
                        <?php } ?>
                    </div>
                   <div class="btn-toolbar" style="margin-left: 67em; margin-top: 3em">
                        <?php if (isset($this->session->userdata['login'])) { ?>
                        <a href="#form-pokemon" data-toggle="modal" class="fa fa-plus"><b> Add Pokemon</b></a>
                        <?php } ?>
                    </div>
                    <div id="no-more-tables">
                        <table id="tabeldata" width="100%" class="table-bordered table-striped table-condensed cf" style="text-align: center;">
                            <thead class="cf" style="background: #337ab7;color: white;">
                                <tr>
                                    <th>No</th>
                                    <th>Nama Pokemon</th>
                                    <th>Nama elemen</th>
                                    <th>Photo</th>
                                    <?php if (isset($this->session->userdata['login'])) { ?>
                                        <th>Action</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody style="background: #fff">
                                <?php
                                $no = 1;
                                foreach ($pokemon_elemen_tb as $key) {
                                    ?>
                                    <tr>
                                        <td data-title="No."><?php echo $no++ ?></td>
                                        <td data-title="Nama Pokemon"><?php echo $key->name_pokemon ?></td>
                                        <td data-title="Nama Elemen"><?php echo $key->name_elemen ?></td>
                                        <td data-title="Photo"><?php echo $key->photo ?></td>
                                        <?php if (isset($this->session->userdata['login'])) { ?>
                                            <td data-title="Action" style="width: 10em; text-align: center;"><span style="display:inline-block; width:1.5em;"></span><a href="pokemon/hapus/<?php echo $key->id ?>" class="fa fa-trash"></a></td>
                                        <?php } ?>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div><!-- /.row -->
                </div>
            </div>
        </div>
        <!-- End Feature Section -->

        <!-- Start form pokemon Section -->
        <div class="section-modal modal fade" id="form-pokemon" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3> Masukkan Data Pokemon </h3>
                        </div>
                    </div>
                    <div class="row" style="width: 50%; margin: auto">
                        <form class="" action="pokemon/insert_pokemon" method="post">
                            <div class="form-group">
                                <label>Nama Pokemon</label>
                                <input type="text" class="form-control" name="name" placeholder="Nama Pokemon">
                            </div>
                            <div class="form-group">
                                <label>STR</label>
                                <input type="text" class="form-control" name="str" placeholder="Str">
                            </div>
                            <div class="form-group">
                                <label>Definisi</label>
                                <input type="text" class="form-control" name="def" placeholder="Definisi">
                            </div>
                            <div class="form-group">
                                <label>Photo</label>
                                <input type="text" class="form-control" name="def" placeholder="Photo">
                            </div>
                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End pokemon Section -->

        <!-- Start form elemen Section -->
        <div class="section-modal modal fade" id="form-elemen" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-content">
                <div class="close-modal" data-dismiss="modal">
                    <div class="lr">
                        <div class="rl">
                        </div>
                    </div>
                </div>

                <div class="container">
                    <div class="row">
                        <div class="section-title text-center">
                            <h3> Masukkan Data Elemen </h3>
                        </div>
                    </div>
                    <div class="row" style="width: 50%; margin: auto">
                        <form class="" action="pokemon/insert_elemen" method="post">
                            <div class="form-group">
                                <label>Nama Elemen</label>
                                <input type="text" class="form-control" name="name" placeholder="Nama Elemen">
                            </div>
                            <button type="submit" class="btn btn-default">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- End elemen Section -->
    </body>
</html>
