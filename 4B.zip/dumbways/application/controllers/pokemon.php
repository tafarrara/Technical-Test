<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class pokemon extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('m_pokemon');
    }

    public function index() {
        $data['pokemon_elemen_tb'] = $this->m_pokemon->get_data()->result();
        $this->load->view('view_pokemon', $data);
    }

    public function insert_pokemon() {
        $name = $this->input->post('name');
        $str = $this->input->post('str');
        $def = $this->input->post('def');
        $photo = $this->input->post('photo');

        $data = array(
            'name' => $name,
            'str' => $str,
            'def' => $def,
            'photo' => $photo
        );

        $this->m_pokemon->input_data($data, 'pokemon_tb');
        redirect(base_url('pokemon'));
    }


    public function insert_elemen() {
        $name = $this->input->post('name');

        $data = array(
            'name' => $name
        );

        $this->m_pokemon->input_data($data, 'elemen_tb');
        redirect(base_url('pokemon'));
    }

    function hapus($id) {
        $id = array('id' => $id);
        $this->m_pokemon->hapus_data($id, 'pokemon_elemen_tb');
        redirect('pokemon');
    }

}

?>
