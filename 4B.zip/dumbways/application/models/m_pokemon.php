<?php
class m_pokemon extends CI_Model{
	function get_data(){
		return $this->db->get('pokemon_elemen_tb');
      // $this->db->select('*');
      // $this->db->from('elemen_tb');
      // $this->db->join('pokemon_tb','pokemon_tb.id = elemen_tb.id');      
      // $query = $this->db->get();
      // return $query;
	}

	function input_data($data, $table){
		$this->db->insert($table, $data);
	}


	function hapus_data($id,$table){
		$this->db->where($id);
		$this->db->delete($table);
}

}

?>
